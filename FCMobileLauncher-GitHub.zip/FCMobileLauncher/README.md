# FC Mobile Hub

Basit Android başlatıcı projesi. Ana ekrandaki BAŞLAT düğmesi, ilk kullanımda Android'in
“Diğer uygulamaların üzerinde göster” izin ekranını açar. İzin verildikten sonra düğmeye
yeniden basıldığında FC Mobile açılır ve sürüklenebilir küçük FC balonu gösterilir.
Balona dokunmak da oyunu açar.

## GitHub'a yükleme
1. ZIP'i çıkar.
2. Klasörü Android Studio ile aç.
3. Gradle senkronizasyonunun tamamlanmasını bekle.
4. `Build > Build APK(s)` ile APK oluştur.

## Notlar
- FC Mobile paket adı `com.ea.gp.fifamobile` olarak ayarlanmıştır. Mağaza sürümünün paket adı farklıysa
  `MainActivity.java` ve `OverlayService.java` içindeki paket adını güncelle.
- Bu proje oyunun dosyalarını, sunucu verilerini, para bakiyesini veya maç mekaniklerini değiştirmez.
- Android sürümü/üreticiye göre balonun arka planda kalma davranışı değişebilir.
